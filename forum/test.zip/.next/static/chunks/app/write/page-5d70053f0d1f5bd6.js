(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[79],{6092:function(e,r,t){Promise.resolve().then(t.bind(t,969))},969:function(e,r,t){"use strict";t.r(r),t.d(r,{default:function(){return o}});var n=t(7437);function o(){return(0,n.jsx)("input",{type:"file",accept:"image/*",onChange:e=>{let r=e.target.files;console.log(URL.createObjectURL(r))}})}},622:function(e,r,t){"use strict";/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var n=t(2265),o=Symbol.for("react.element"),f=Symbol.for("react.fragment"),u=Object.prototype.hasOwnProperty,c=n.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,s={key:!0,ref:!0,__self:!0,__source:!0};function i(e,r,t){var n,f={},i=null,_=null;for(n in void 0!==t&&(i=""+t),void 0!==r.key&&(i=""+r.key),void 0!==r.ref&&(_=r.ref),r)u.call(r,n)&&!s.hasOwnProperty(n)&&(f[n]=r[n]);if(e&&e.defaultProps)for(n in r=e.defaultProps)void 0===f[n]&&(f[n]=r[n]);return{$$typeof:o,type:e,key:i,ref:_,props:f,_owner:c.current}}r.Fragment=f,r.jsx=i,r.jsxs=i},7437:function(e,r,t){"use strict";e.exports=t(622)}},function(e){e.O(0,[971,864,744],function(){return e(e.s=6092)}),_N_E=e.O()}]);