(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[262],{3069:function(e,r,n){Promise.resolve().then(n.bind(n,7743))},7743:function(e,r,n){"use strict";n.r(r),n.d(r,{default:function(){return o}});var t=n(7437);function o(e){let{error:r,reset:n}=e;return console.log(r,"?????"),(0,t.jsxs)("div",{children:[(0,t.jsx)("h3",{children:"에러~~"}),(0,t.jsx)("button",{onClick:()=>{n()},children:"버튼"})]})}},622:function(e,r,n){"use strict";/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var t=n(2265),o=Symbol.for("react.element"),s=Symbol.for("react.fragment"),u=Object.prototype.hasOwnProperty,c=t.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,f={key:!0,ref:!0,__self:!0,__source:!0};function i(e,r,n){var t,s={},i=null,l=null;for(t in void 0!==n&&(i=""+n),void 0!==r.key&&(i=""+r.key),void 0!==r.ref&&(l=r.ref),r)u.call(r,t)&&!f.hasOwnProperty(t)&&(s[t]=r[t]);if(e&&e.defaultProps)for(t in r=e.defaultProps)void 0===s[t]&&(s[t]=r[t]);return{$$typeof:o,type:e,key:i,ref:l,props:s,_owner:c.current}}r.Fragment=s,r.jsx=i,r.jsxs=i},7437:function(e,r,n){"use strict";e.exports=n(622)}},function(e){e.O(0,[971,864,744],function(){return e(e.s=3069)}),_N_E=e.O()}]);