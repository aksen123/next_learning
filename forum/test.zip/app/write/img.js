'use client'
export default function Image() {
  const change = (e)=>{
    let test = e.target.files
    let aa = URL.createObjectURL(test)
    console.log(aa)
  }

  return (
    <input type="file" accept="image/*" onChange={change}/>
  )
}