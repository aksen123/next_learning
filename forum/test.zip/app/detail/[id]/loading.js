export default function Loading(){
  return (
    <h2>로딩중~~~~</h2>
  )
}